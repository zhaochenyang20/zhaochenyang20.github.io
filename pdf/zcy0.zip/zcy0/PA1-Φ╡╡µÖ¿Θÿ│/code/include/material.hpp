#ifndef MATERIAL_H
#define MATERIAL_H

#include <cassert>
#include <vecmath.h>

#include "ray.hpp"
#include "hit.hpp"
#include <iostream>

// TODO: Implement Shade function that computes Phong introduced in class.
class Material {
public:

    explicit Material(const Vector3f &d_color, const Vector3f &s_color = Vector3f::ZERO, float s = 0) :
            diffuseColor(d_color), specularColor(s_color), shininess(s) {

    }

    virtual ~Material() = default;

    virtual Vector3f getDiffuseColor() const {
        return diffuseColor;
    }

    inline float clamp(float x) { return x > 0 ? x : 0; }
    Vector3f Shade(const Ray &ray, const Hit &hit,
                   const Vector3f &dirToLight, const Vector3f &lightColor) {
        Vector3f shaded = Vector3f::ZERO;
        // Phong
        Vector3f N = hit.getNormal().normalized();
        Vector3f L = dirToLight.normalized();
        Vector3f V = -(ray.getDirection().normalized());
        Vector3f R = (2 * Vector3f::dot(N, L) * N - L).normalized();

        Vector3f diffuse = diffuseColor * clamp(Vector3f::dot(L, N)); //漫反射 
        Vector3f specular;
        if (Vector3f::dot(V, R) > 0) {
            specular = specularColor * pow(Vector3f::dot(V, R), shininess); //镜面反射
        }
        else specular = Vector3f::ZERO; //镜面反射
        return lightColor * (diffuse + specular);
    }

protected:
    Vector3f diffuseColor;
    Vector3f specularColor;
    float shininess;
};


#endif // MATERIAL_H
