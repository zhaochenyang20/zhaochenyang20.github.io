#ifndef SPHERE_H
#define SPHERE_H

#include "object3d.hpp"
#include <vecmath.h>
#include <cmath>

// TODO: Implement functions and add more fields as necessary

class Sphere : public Object3D {
public:
    Sphere() {
        // unit ball at the center
        center = Vector3f(0.0f, 0.0f, 0);
        radius = 1.0f;
    }

    Sphere(const Vector3f &center, float radius, Material *material) : Object3D(material), center (center), radius (radius) {}

    ~Sphere() override = default;

    bool intersect(const Ray &r, Hit &h, float tmin) override {
        auto heartToRaw {center - r.getOrigin()};
        // 圆心到光线的起点的向量
        auto dotProduct {Vector3f::dot(heartToRaw, r.getDirection().normalized())};
        if (dotProduct <= 0 && heartToRaw.length() > radius) return false;
        // 如果圆心到光线起点的向量的长度大于半径，且夹角大于 90 度，则不相交
        auto projection {heartToRaw.length() * heartToRaw.length() - dotProduct * dotProduct};
        if (projection > radius * radius) return false;
        // 勾股定理
        auto inside {false};
        if (heartToRaw.length() <= radius)  inside = true;
        auto row {dotProduct - sqrt(radius * radius - projection)};
        if (inside) row = dotProduct + sqrt(radius * radius - projection);
        if (row < 0 || row < tmin || row > h.getT())    return false;
        h.set(row, material, (r.getDirection() * row - heartToRaw).normalized() * (inside ? -1.0f : 1.0f));
        return true;
    }

protected:
    Vector3f center;
    float radius;
};


#endif
