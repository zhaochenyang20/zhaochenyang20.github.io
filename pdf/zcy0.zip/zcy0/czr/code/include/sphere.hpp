#ifndef SPHERE_H
#define SPHERE_H

#include "object3d.hpp"
#include <vecmath.h>
#include <cmath>
#include <glut.h>

// DONE (PA2): Copy from PA1
class Sphere : public Object3D {
   public:
    Sphere() {
        // unit ball at the center
    }

    Sphere(const Vector3f &center, float radius, Material *material) :
    Object3D(material)
    {
        //
        Center = center;
        Radius = radius;
    }

    ~Sphere() override = default;

    bool intersect(const Ray &r, Hit &h, float tmin) override {
        //
        Vector3f O(r.getOrigin()), R(r.getDirection()), OC(Center - O);
        R.normalize();
        float OH = Vector3f::dot(OC, R);
        float CH = sqrt(OC.length() * OC.length() - OH * OH);
        if (CH > Radius) return false;
        float PH = sqrt(Radius * Radius - CH * CH);
        float OP = OH - PH;
        if (OP < tmin || OP > h.getT()) return false;
        Vector3f P(O + R * OP);
        Vector3f N((P - Center).normalized());
        h.set(OP, material, N);
        return true;
    }

    void drawGL() override {
        Object3D::drawGL();
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glTranslatef(Center.x(), Center.y(), Center.z());
        glutSolidSphere(Radius, 80, 80);
        glPopMatrix();
    }

protected:
    Vector3f Center;
    float Radius;
};


#endif
