#ifndef PLANE_H
#define PLANE_H

#include "object3d.hpp"
#include <vecmath.h>
#include <cmath>

// DONE (PA2): Copy from PA1

class Plane : public Object3D {
   public:
    Plane() {
        N = Vector3f::UP;
        D = 0;
    }

    Plane(const Vector3f &normal, float d, Material *m) : Object3D(m) {
        N = normal;
        D = d;
    }

    ~Plane() override = default;

    bool intersect(const Ray &r, Hit &h, float tmin) override {
        Vector3f O(r.getOrigin()), R(r.getDirection());
        if (fabs(Vector3f::dot(N, R)) < 1e-6) return false;
        float OP = (D - Vector3f::dot(N, O))/(Vector3f::dot(N, R));
        if (OP < tmin || OP > h.getT()) return false;
        if (Vector3f::dot(N, R) <= 0)
            h.set(OP, material, N);
        else
            h.set(OP, material, -N);
        return true;
    }

    void drawGL() override {
        Object3D::drawGL();
        Vector3f xAxis = Vector3f::RIGHT;
        Vector3f yAxis = Vector3f::cross(N, xAxis);
        xAxis = Vector3f::cross(yAxis, N);
        const float planeSize = 10.0;
        glBegin(GL_TRIANGLES);
        glNormal3fv(N);
        glVertex3fv(D * N + planeSize * xAxis + planeSize * yAxis);
        glVertex3fv(D * N - planeSize * xAxis - planeSize * yAxis);
        glVertex3fv(D * N + planeSize * xAxis - planeSize * yAxis);
        glNormal3fv(N);
        glVertex3fv(D * N + planeSize * xAxis + planeSize * yAxis);
        glVertex3fv(D * N - planeSize * xAxis + planeSize * yAxis);
        glVertex3fv(D * N - planeSize * xAxis - planeSize * yAxis);
        glEnd();
    }

   protected:
    Vector3f N;
    float D;
};

#endif //PLANE_H
		

