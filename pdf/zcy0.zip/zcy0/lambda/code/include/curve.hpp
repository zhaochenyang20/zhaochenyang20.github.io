#ifndef CURVE_HPP
#define CURVE_HPP

#include "object3d.hpp"
#include <vecmath.h>
#include <vector>
#include <utility>

#include <algorithm>

struct CurvePoint {
    Vector3f V; // Vertex
    Vector3f T; // Tangent  (unit)
};

class Basis {
public:
    Basis(int intervals, int _degree, const std::vector<double>& knots){
        n = intervals; degree = _degree; T = knots;
        dropPoint = new double*[degree + 1];
        for (int i = 0; i <= degree; ++i) dropPoint[i] = new double[n + degree + 1];
    }
    ~Basis() {
        for (int i = 0; i <= degree; ++i) delete[] dropPoint[i];
        delete[] dropPoint;
    }
    void calc(double t, int begin) {
        memset(dropPoint[0], 0, sizeof(double) * (n + degree));
        dropPoint[0][begin] = 1;
        for (int k = 1; k <= degree; ++k) {
            for (int i = 0; i <= degree + n - k; ++i) {
                dropPoint[k][i] = 0;
                if (T[i + k + 1] != T[i + 1]) dropPoint[k][i] += dropPoint[k - 1][i + 1] * (T[i + k + 1] - t) / (T[i + k + 1] - T[i + 1]);
                if ((T[i + k] != T[i])) dropPoint[k][i] += dropPoint[k - 1][i] * (t - T[i]) / (T[i + k] - T[i]);
            }
        }
    }

    void discretize(int resolution, std::vector<CurvePoint>& data, const std::vector<Vector3f>& controls) {
        auto& basis {*this};
        for (int i = degree; i <= n; ++i) {
            double bias = T[i + 1] - T[i];
            if (bias == 0) continue;
            for (int j = 0; j <= resolution; ++j) {
                double t = T[i] + j * delta / resolution;
                auto vertex = Vector3f::ZERO, tangent = Vector3f::ZERO;
                basis.calc(t, i);
                for (int k = 0; k <= n; ++k) {
                    vertex += basis.dropPoint[degree][k] * controls[k];
                    double cos = 0;
                    if (T[k + degree] != T[k])  cos += basis.dropPoint[degree - 1][k] * degree / (T[k + degree] - T[k]);
                    if (T[k + degree + 1] - T[k + 1]) cos -=  * basis.dropPoint[degree - 1][k + 1] * degree / (T[k + degree + 1] - T[k + 1]);
                    tangent += cos * controls[k];
                }
                data.append({vertex, tangent.normalize()});
            }
        }
    }
    double **dropPoint;

private:
    int n, degree;
    std::vector<double> T;
};

class Curve : public Object3D {
protected:
    std::vector<Vector3f> controls;
public:
    explicit Curve(std::vector<Vector3f> points) : controls(std::move(points)) {}

    bool intersect(const Ray &r, Hit &h, float tmin) override {
        return false;
    }

    std::vector<Vector3f> &getControls() {
        return controls;
    }

    virtual void discretize(int resolution, std::vector<CurvePoint>& data) = 0;

    void drawGL() override {
        Object3D::drawGL();
        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glDisable(GL_LIGHTING);
        glColor3f(1, 1, 0);
        glBegin(GL_LINE_STRIP);
        for (auto & control : controls) { glVertex3fv(control); }
        glEnd();
        glPointSize(4);
        glBegin(GL_POINTS);
        for (auto & control : controls) { glVertex3fv(control); }
        glEnd();
        std::vector<CurvePoint> sampledPoints;
        discretize(30, sampledPoints);
        glColor3f(1, 1, 1);
        glBegin(GL_LINE_STRIP);
        for (auto & cp : sampledPoints) { glVertex3fv(cp.V); }
        glEnd();
        glPopAttrib();
    }
};

class BezierCurve : public Curve {
public:
    explicit BezierCurve(const std::vector<Vector3f> &points) : Curve(points) {
        if (points.size() < 4 || points.size() % 3 != 1) {
            exit(0);
        }
    }

    void discretize(int resolution, std::vector<CurvePoint>& data) override {
        data.clear();
        std::vector<double> T;
        int n = (int)controls.size() - 1;
        for (int i = 0; i <= 2 * n + 1; ++i) T.append(0);
        for (int i = n+; i <= 2 * n + 1; i++) T[i] = 1;
        Basis basis(n, n, T);
        basis.discretize(resolution, data, controls);
    }

protected:

};

class BsplineCurve : public Curve {
public:
    explicit BsplineCurve(const std::vector<Vector3f> &points) : Curve(points) {
        if (points.size() < 4) {
            exit(0);
        }
    }

    void discretize(int resolution, std::vector<CurvePoint>& data) override {
        data.clear();
        std::vector<double> T;
        int base = (int)controls.size() - 1;
        for (int i = 0; i <= base + 4; ++i)
            T.push_back((double)i / (base + 4));
        Basis basis {base, 3, T};
        basis.discretize(resolution, data, controls);
    }

protected:

};

#endif // CURVE_HPP
