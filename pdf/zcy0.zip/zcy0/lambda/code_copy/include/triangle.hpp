#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "object3d.hpp"
#include <vecmath.h>
#include <cmath>
#include <iostream>

using namespace std;

// TODO (PA2): Copy from PA1
class Triangle: public Object3D
{

public:
	Triangle() = delete;

    // a b c are three vertex positions of the triangle
	Triangle( const Vector3f& a, const Vector3f& b, const Vector3f& c, Material* m) :
		Object3D(m), a {a}, b {b}, c {c}, normal{Vector3f::cross(a - b, a - c).normalized()}
		{}

	bool intersect( const Ray& r,  Hit& h , float tmin) override {
		auto e1 {a - b}, e2 {a - c}, s {a - r.getOrigin()}, rd {r.getDirection()};
        auto det {Matrix3f(rd, e1, e2).determinant()};
		auto t {Matrix3f(s, e1, e2).determinant() / det};
		auto beta {Matrix3f(rd, s, e2).determinant() / det};
		auto gamma {Matrix3f(rd, e1, s).determinant() / det};

		if (t > 0 && t >= tmin && t < h.getT()
		&& 0 <= beta && beta <= 1
		&& 0 <= gamma && gamma <= 1
		&& beta + gamma <= 1
		) {
			h.set(t, material, normal);
			if (Vector3f::dot(normal, rd) > 0)	h.set(t, material, -normal);
			return true;
		}
		return false;
	}
	
	Vector3f normal;

void drawGL() override {
        Object3D::drawGL();
        glBegin(GL_TRIANGLES);
        glNormal3fv(normal);
        glVertex3fv(a); glVertex3fv(b); glVertex3fv(c);
        glEnd();
    }
protected:
	Vector3f a, b, c;
};

#endif //TRIANGLE_H
