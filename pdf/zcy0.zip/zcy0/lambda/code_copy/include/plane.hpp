#ifndef PLANE_H
#define PLANE_H

#include "object3d.hpp"
#include <vecmath.h>
#include <cmath>

// DONE (PA2): Copy from PA1

class Plane : public Object3D {

protected:
    Vector3f normal;
    float point;

public:
    Plane(): point{0}, normal{Vector3f(0, 0, 0)} {}

    Plane(const Vector3f &_normal, float _point, Material *_m) : Object3D{_m}, normal{_normal.normalized()}, point{_point} {}

    ~Plane() override = default;

    bool intersect(const Ray &ray, Hit &hit, float tmin) override {
        float dotProduct = Vector3f::dot(normal, ray.getDirection().normalized());
        if( dotProduct == 0)    return false;
        float t = (point - Vector3f::dot(normal, ray.getOrigin())) / dotProduct;
        if(t < tmin)    return false;
        //! hit points
        Vector3f hitVector;
        if(Vector3f::dot(ray.getDirection(), normal) > 0) hitVector = -normal;
        else hitVector = normal;
        hit.set(t, material, hitVector);
        return true;
    }

    void drawGL() override {
        Object3D::drawGL();
        Vector3f xAxis = Vector3f::RIGHT;
        Vector3f yAxis = Vector3f::cross(normal, xAxis);
        xAxis = Vector3f::cross(yAxis, normal);
        const float planeSize = 10.0;
        glBegin(GL_TRIANGLES);
        glNormal3fv(normal);
        glVertex3fv(point * normal + planeSize * xAxis + planeSize * yAxis);
        glVertex3fv(point * normal - planeSize * xAxis - planeSize * yAxis);
        glVertex3fv(point * normal + planeSize * xAxis - planeSize * yAxis);
        glNormal3fv(normal);
        glVertex3fv(point * normal + planeSize * xAxis + planeSize * yAxis);
        glVertex3fv(point * normal - planeSize * xAxis + planeSize * yAxis);
        glVertex3fv(point * normal - planeSize * xAxis - planeSize * yAxis);
        glEnd();
    }

};

#endif //PLANE_H
		

