#ifndef PLANE_H
#define PLANE_H

#include "object3d.hpp"
#include <vecmath.h>
#include <cmath>

// DONE (PA2): Copy from PA1

class Plane : public Object3D {

protected:
    Vector3f normal;
    float d;

public:
    Plane() {
        // xy plane
        d = 0;
        normal = Vector3f(0, 0, 1);
        return;
    }

    Plane(const Vector3f &_normal, float _d, Material *_m) : Object3D(_m) {
        normal = _normal.normalized();
        d = _d;
        return;
    }

    ~Plane() override = default;

    bool intersect(const Ray &ray, Hit &hit, float tmin) override {
        float dotND = Vector3f::dot(normal, ray.getDirection().normalized());
        if( dotND == 0){
            return false;
        }
        float t = (d - Vector3f::dot(normal, ray.getOrigin())) / dotND;
        if(t < tmin){
            return false;
        }
        Vector3f n;
        if(Vector3f::dot(ray.getDirection(), normal) > 0) n = -1 * normal;
        else n = normal;
        hit.set(t, material, n);
        return true;
    }

    void drawGL() override {
        Object3D::drawGL();
        Vector3f xAxis = Vector3f::RIGHT;
        Vector3f yAxis = Vector3f::cross(normal, xAxis);
        xAxis = Vector3f::cross(yAxis, normal);
        const float planeSize = 10.0;
        glBegin(GL_TRIANGLES);
        glNormal3fv(normal);
        glVertex3fv(d * normal + planeSize * xAxis + planeSize * yAxis);
        glVertex3fv(d * normal - planeSize * xAxis - planeSize * yAxis);
        glVertex3fv(d * normal + planeSize * xAxis - planeSize * yAxis);
        glNormal3fv(normal);
        glVertex3fv(d * normal + planeSize * xAxis + planeSize * yAxis);
        glVertex3fv(d * normal - planeSize * xAxis + planeSize * yAxis);
        glVertex3fv(d * normal - planeSize * xAxis - planeSize * yAxis);
        glEnd();
    }

};

#endif //PLANE_H
		

