from PIL import Image
from numpy import asarray, abs
import matplotlib.pyplot as plt
from pathlib import Path

root  = Path().resolve()
out = root / "output"
std = root / "std"


img = Image.open("1.png")
img_std = Image.open("1_std.png")
assert img.format == img_std.format
data = asarray(img)
data_std = asarray(img_std)
delta = abs(data - data_std)
d_img = Image.fromarray(delta)
plt.imshow(d_img)

