#ifndef SPHERE_H
#define SPHERE_H

#include "object3d.hpp"
#include <vecmath.h>
#include <cmath>
#include <glut.h>

class Sphere : public Object3D {
public:
    Sphere() {
        // unit ball at the center
        this->center = Vector3f(0, 0, 0);
        this->radius = 1.0;
    }

    Sphere(const Vector3f &center, float radius, Material *material) : Object3D(material) {
        this->center = center;
        this->radius = radius;
    }

    ~Sphere() override = default;

    bool intersect(const Ray &r, Hit &h, float tmin) override {
        Vector3f l = center - r.getOrigin();
        float t_p = Vector3f::dot(l, r.getDirection().normalized());
        if (l.length() > radius && t_p < 0) return false;
        float d2 = l.length() * l.length() - t_p * t_p;
        if(d2 > radius * radius) return false;

        float t;
        if (l.length() > radius)
            t = t_p - sqrt(radius * radius - d2);
        else
            t = t_p + sqrt(radius * radius - d2);
        if (t < h.getT() && t > tmin)
        {
            if (l.length() > radius){
                h.set(t, material, (r.pointAtParameter(t) - center).normalized());
                return true;
            } 
            else {
                h.set(t, material, (center - r.pointAtParameter(t)).normalized());
                return true;
            }
        }
        else
            return false;
    }

    void drawGL() override {
        Object3D::drawGL();
        glMatrixMode(GL_MODELVIEW); glPushMatrix();
        glTranslatef(center.x(), center.y(), center.z());
        glutSolidSphere(radius, 80, 80);
        glPopMatrix();
    }

protected:
    Vector3f center;
    float radius;

};


#endif
