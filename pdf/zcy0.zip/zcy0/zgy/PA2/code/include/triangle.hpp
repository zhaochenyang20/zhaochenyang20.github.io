#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "object3d.hpp"
#include <vecmath.h>
#include <cmath>
#include <iostream>

using namespace std;

class Triangle: public Object3D
{

public:
	Triangle() = delete;
        ///@param a b c are three vertex positions of the triangle

	Triangle( const Vector3f& a, const Vector3f& b, const Vector3f& c, Material* m) : Object3D(m) {
        vertices[0] = a;
		vertices[1] = b;
		vertices[2] = c;
		normal = Vector3f::cross(a - b, a - c).normalized();
	}

	bool intersect( const Ray& ray,  Hit& hit , float tmin) override {
        Vector3f E_1 = vertices[0] - vertices[1];
		Vector3f E_2 = vertices[0] - vertices[2];
		Vector3f S = vertices[0] - ray.getOrigin();
		Vector3f R_d = ray.getDirection();

		float t = Matrix3f(S, E_1, E_2).determinant() / Matrix3f(R_d, E_1, E_2).determinant();
		float beta = Matrix3f(R_d, S, E_2).determinant() / Matrix3f(R_d, E_1, E_2).determinant();
		float gamma = Matrix3f(R_d, E_1, S).determinant() / Matrix3f(R_d, E_1, E_2).determinant();

		if (t > 0 && t < hit.getT() && t > tmin && beta >= 0 && beta <= 1 && gamma >= 0 && gamma <= 1 && beta + gamma <= 1)
		{
			if (Vector3f::dot(normal, ray.getDirection()) < 0) {
				hit.set(t, material, normal);
				return true;
			}
			else {
				hit.set(t, material, -normal);
				return true;
			}
		}
		else return false;
	}
	Vector3f normal;
	Vector3f vertices[3];

    void drawGL() override {
        Object3D::drawGL();
        glBegin(GL_TRIANGLES);
        glNormal3fv(normal);
        glVertex3fv(vertices[0]); glVertex3fv(vertices[1]); glVertex3fv(vertices[2]);
        glEnd();
    }

protected:

};

#endif //TRIANGLE_H
