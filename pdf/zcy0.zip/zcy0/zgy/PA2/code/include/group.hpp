#ifndef GROUP_H
#define GROUP_H


#include "object3d.hpp"
#include "ray.hpp"
#include "hit.hpp"
#include <iostream>
#include <vector>


class Group : public Object3D {

public:

    Group() {
        geoGroup = std::vector<Object3D *>();
    }

    explicit Group (int num_objects) {
        geoGroup = std::vector<Object3D *>(num_objects);
    }

    ~Group() override {

    }

    bool intersect(const Ray &r, Hit &h, float tmin) override {
        bool hit = false;
        for (int i = 0; i < geoGroup.size(); i++) {
            if (geoGroup[i]->intersect(r, h, tmin)) {
                hit = true;
            }
        }
        return hit;
    }

    void drawGL() override {
        for (int i = 0; i < geoGroup.size(); i++) {
            geoGroup[i]->drawGL();
        }
    }

    void addObject(int index, Object3D *obj) {
        geoGroup[index] = obj;
    }

    int getGroupSize() {
        return geoGroup.size();
    }

private:
    std::vector<Object3D *> geoGroup;
};


#endif
	
