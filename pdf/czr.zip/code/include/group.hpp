#ifndef GROUP_H
#define GROUP_H


#include "object3d.hpp"
#include "ray.hpp"
#include "hit.hpp"
#include <iostream>
#include <vector>


// DONE (PA2): Implement Group - copy from PA1
// Implement Group - add data structure to store a list of Object*
class Group : public Object3D {
 public:
    Group() {}

    explicit Group(int num_objects) : objList(num_objects) {}

    ~Group() override {}

    void drawGL() override {
        for (auto obj : objList)
            if (obj) obj->drawGL();
    }

    bool intersect(const Ray &r, Hit &h, float tmin) override {
        bool flag = false;
        for (auto obj : objList)
            if (obj) flag |= obj->intersect(r, h, tmin);
        return flag;
    }

    void addObject(int index, Object3D *obj) {
        objList.insert(objList.begin() + index, obj);
    }

    int getGroupSize() { return objList.size(); }

   private:
    std::vector<Object3D *> objList;
};

#endif
	
