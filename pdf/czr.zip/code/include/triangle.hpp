#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "object3d.hpp"
#include <vecmath.h>
#include <cmath>
#include <iostream>

using namespace std;

// DONE (PA2): Copy from PA1 (DONE)
class Triangle : public Object3D {
   public:
    Vector3f normal;
    Vector3f a, b, c;
    float D;

	Triangle() = delete;

    // a b c are three vertex positions of the triangle
	Triangle( const Vector3f& a, const Vector3f& b, const Vector3f& c, Material* m) :
    Object3D(m), a(a), b(b), c(c) {
        normal = Vector3f::cross((a - b), (b - c)).normalized();
        D = - Vector3f::dot(normal, a);
	}

	bool intersect( const Ray& ray,  Hit& hit , float tmin) override {
        Vector3f O(ray.getOrigin()), R(ray.getDirection());
        if (fabs(Vector3f::dot(normal, R)) < 1e-6) return false;
        float OP = -(D + Vector3f::dot(normal, O)) / (Vector3f::dot(normal, R));
        if (OP < tmin || OP > hit.getT()) return false;
        Vector3f P(O + OP * R);
        bool inside = (Vector3f::dot(Vector3f::cross((a - P), (b - P)), normal) >= 0) &&
                      (Vector3f::dot(Vector3f::cross((b - P), (c - P)), normal) >= 0) &&
                      (Vector3f::dot(Vector3f::cross((c - P), (a - P)), normal) >= 0);
        if (!inside) return false;
        hit.set(OP, material, normal);
        return true;
    }
    
    void drawGL() override {
        Object3D::drawGL();
        glBegin(GL_TRIANGLES);
        glNormal3fv(normal);
        glVertex3fv(a);
        glVertex3fv(b);
        glVertex3fv(c);
        glEnd();
    }

   protected:
    bool inTriangle(const Vector3f& p) {
        return Vector3f::dot(Vector3f::cross((b - p), (c - p)), normal) >=
                   -1e-6 &&
               Vector3f::dot(Vector3f::cross((c - p), (a - p)), normal) >=
                   -1e-6 &&
               Vector3f::dot(Vector3f::cross((a - p), (b - p)), normal) >=
                   -1e-6;
    }
};


#endif //TRIANGLE_H
