#ifndef CURVE_HPP
#define CURVE_HPP

#include "object3d.hpp"
#include <vecmath.h>
#include <vector>
#include <utility>

#include <algorithm>

// TODO (PA2): Implement Bernstein class to compute spline basis function.
//       You may refer to the python-script for implementation.

// The CurvePoint object stores information about a point on a curve
// after it has been tesselated: the vertex (V) and the tangent (T)
// It is the responsiblility of functions that create these objects to fill in all the data.
struct CurvePoint {
    Vector3f V; // Vertex
    Vector3f T; // Tangent  (unit)
};

class Curve : public Object3D {
protected:
    std::vector<Vector3f> controls;
public:

    int n, k;
    std::vector<double> t;
    double range[2];

    explicit Curve(std::vector<Vector3f> points) : controls(std::move(points)) {

    }

    bool intersect(const Ray &r, Hit &h, float tmin) override {
        return false;
    }

    std::vector<Vector3f> &getControls() {
        return controls;
    }

    virtual void discretize(int resolution, std::vector<CurvePoint>& data) = 0;

    int get_bpos(double mu) {
        return (int) (upper_bound(t.begin(), t.end(), mu) - t.begin() - 1);
    }

    void drawGL() override {
        Object3D::drawGL();
        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glDisable(GL_LIGHTING);
        glColor3f(1, 1, 0);
        glBegin(GL_LINE_STRIP);
        for (auto & control : controls) { glVertex3fv(control); }
        glEnd();
        glPointSize(4);
        glBegin(GL_POINTS);
        for (auto & control : controls) { glVertex3fv(control); }
        glEnd();
        std::vector<CurvePoint> sampledPoints;
        discretize(30, sampledPoints);
        glColor3f(1, 1, 1);
        glBegin(GL_LINE_STRIP);
        for (auto & cp : sampledPoints) { glVertex3fv(cp.V); }
        glEnd();
        glPopAttrib();
    }
};

class BezierCurve : public Curve {
public:
    explicit BezierCurve(const std::vector<Vector3f> &points) : Curve(points) {
        if (points.size() < 4 || points.size() % 3 != 1) {
            printf("Number of control points of BezierCurve must be 3n+1!\n");
            exit(0);
        }
        n = (int) controls.size();
        k = n - 1;
        range[0] = 0;
        range[1] = 1;
        t.resize(2 * n);
        for (int i = 0; i < n; ++i) {
            t[i] = 0;
            t[i + n] = 1;
        }
    }

    void discretize(int resolution, std::vector<CurvePoint>& data) override {
        data.clear();
        // TODO (PA2): fill in data vector
        resolution *= n / k;
        data.resize(resolution);
        for (int i = 0; i < resolution; i++){
            data[i].T = Vector3f::ZERO;
            data[i].V = Vector3f::ZERO;
            double mu = ((double) i / resolution) * (range[1] - range[0]) + range[0];
            int bpos = get_bpos(mu);
            vector<double> s(k + 2, 0), ds(k + 1, 1);
            s[k] = 1;
            for (int p = 1; p <= k; p++) {
                for (int ii = k - p; ii < k + 1; ii++) {
                    double w1 = mu;
                    double dw1 = 1;
                    double w2 = 1 - mu;
                    double dw2 = -1;
                    if (p == k) ds[ii] = (dw1 * s[ii] + dw2 * s[ii + 1] * p);
                    s[ii] = w1 * s[ii] + w2 * s[ii + 1];
                }
            }
            s.pop_back();
            int lsk = bpos - k;
            int rsk = n - bpos - 1;
            if (lsk < 0) {
                for (int l = 0; l < s.size() + lsk; l++) {
                    s[l] = s[l - lsk];
                }
                for (int l = 0; l < ds.size() + lsk; l++) {
                    ds[l] = ds[l - lsk];
                }
                s.resize(s.size() + lsk);
                ds.resize(ds.size() + lsk);
                lsk = 0;
            }
            if (rsk < 0) {
                s.resize(s.size() + rsk);
                ds.resize(ds.size() + rsk);
            }
            for (int j = 0; j < s.size(); j++) {
                data[i].V += controls[lsk + j] * s[j];
                data[i].T += controls[lsk + j] * ds[j];
            }
        }
    }

protected:

};

class BsplineCurve : public Curve {
public:
    std::vector<double> tpad;
    BsplineCurve(const std::vector<Vector3f> &points) : Curve(points) {
        if (points.size() < 4) {
            printf("Number of control points of BspineCurve must be more than 4!\n");
            exit(0);
        }
        n = controls.size();
        k = 3;
        t.resize(n + k + 1);
        for (int i = 0; i < n + k + 1; ++i) t[i] = (double)i / (n + k);
        //pad
        tpad.resize(t.size() + k);
        for (int i = 0; i < t.size(); ++i){
            tpad[i] = t[i];
        }
        for (int i = 0; i < k; ++i) {
            tpad[i + t.size()] = t.back();
        }
        range[0] = t[k];
        range[1] = t[n];
    }

    void discretize(int resolution, std::vector<CurvePoint>& data) override {
        data.clear();
        // TODO (PA2): fill in data vector

        resolution *= n / k;
        data.resize(resolution);
        for (int i = 0; i < resolution; ++i) {
            data[i].T = Vector3f::ZERO;
            data[i].V = Vector3f::ZERO;
            //生成采样点
            double mu =
                    ((double)i / resolution) * (range[1] - range[0]) + range[0];
            int bpos = upper_bound(t.begin(), t.end(), mu) - t.begin() - 1;
            vector<double> s(k + 2, 0), ds(k + 1, 1);
            s[k] = 1;
            for (int p = 1; p <= k; p++) {
                for (int ii = k - p; ii < k + 1; ii++) {
                    int l = ii + bpos - k;
                    double w1 = (mu - tpad[l]) / (tpad[l + p] - tpad[l]);
                    double dw1 = 1.0 / (tpad[l + p] - tpad[l]);
                    double w2 = (tpad[l + p + 1] - mu) / (tpad[l + p + 1] - tpad[l + 1]);
                    double dw2 = -1 / (tpad[l + p + 1] - tpad[l + 1]);
                    if (p == k) ds[ii] = (dw1 * s[ii] + dw2 * s[ii + 1]) * p;
                    s[ii] = w1 * s[ii] + w2 * s[ii + 1];
                }
            }
            s.pop_back();
            int lsk = bpos - k;
            int rsk = n - bpos - 1;
            if (lsk < 0) {
                for (int l = 0; l < s.size() + lsk; l++) {
                    s[l] = s[l - lsk];
                }
                for (int l = 0; l < ds.size() + lsk; l++) {
                    ds[l] = ds[l - lsk];
                }
                s.resize(s.size() + lsk);
                ds.resize(ds.size() + lsk);
                lsk = 0;
            }
            if (rsk < 0) {
                s.resize(s.size() + rsk);
                ds.resize(ds.size() + rsk);
            }
            for (int j = 0; j < s.size(); j++) {
                data[i].V += controls[lsk + j] * s[j];
                data[i].T += controls[lsk + j] * ds[j];
            }
        }
    }

protected:

};

#endif // CURVE_HPP
