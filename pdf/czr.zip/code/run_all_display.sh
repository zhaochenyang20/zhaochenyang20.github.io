#!/usr/bin/env bash
mkdir -p output
bin/PA2 testcases/scene01_basic.txt
bin/PA2 testcases/scene04_axes.txt
bin/PA2 testcases/scene06_bunny_1k.txt
bin/PA2 testcases/scene08_core.txt
bin/PA2 testcases/scene09_norm.txt
bin/PA2 testcases/scene10_wineglass.txt
